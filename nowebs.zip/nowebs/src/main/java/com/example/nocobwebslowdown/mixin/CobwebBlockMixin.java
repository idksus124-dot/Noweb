package com.example.nocobwebslowdown.mixin;

import com.example.nocobwebslowdown.ModConfig;
import net.minecraft.block.BlockState;
import net.minecraft.block.CobwebBlock;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Mixin for CobwebBlock to bypass the cobweb slowdown logic.
 * Cancels the onEntityCollision method if the colliding entity is the client player
 * and the feature is enabled. This prevents the velocity reduction.
 */
@Mixin(CobwebBlock.class)
public abstract class CobwebBlockMixin {

    @Inject(
        method = "onEntityCollision",
        at = @At("HEAD"),
        cancellable = true
    )
    private void nocobwebslowdown$onEntityCollision(BlockState state, World world, BlockPos pos, Entity entity, CallbackInfo ci) {
        // If it's the client-side world, the entity is a Player, and the mod is enabled...
        if (world.isClient && entity instanceof PlayerEntity && ModConfig.isEnabled()) {
            // ...cancel the method, skipping the code that applies the slowdown.
            ci.cancel();
        }
    }
}