package com.example.nocobwebslowdown;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

/**
 * Main client-side entrypoint for the No Cobweb Slowdown mod.
 * Initializes configuration, keybinding (F7), and HUD rendering.
 */
public class NoCobwebSlowdownClient implements ClientModInitializer {
    private static KeyBinding toggleKey;

    @Override
    public void onInitializeClient() {
        ModConfig.load();

        // Register Keybinding (F7)
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.nocobwebslowdown.toggle", 
            InputUtil.Type.KEYSYM,
            GLFW.GLFW_KEY_F7, 
            "category.nocobwebslowdown.general"
        ));

        // Key Press Event Listener
        net.fabricmc.fabric.api.client.event.v1.ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleKey.wasPressed()) {
                ModConfig.toggle();
                if (client.player != null) {
                    String status = ModConfig.isEnabled() ? "§aEnabled" : "§cDisabled";
                    client.player.sendMessage(Text.literal("Cobweb Speed Bypass: " + status), true);
                }
            }
        });

        // HUD Renderer
        HudRenderCallback.EVENT.register((drawContext, tickDelta) -> {
            if (client.player != null && client.world != null) {
                String text = ModConfig.isEnabled() ? "Cobweb Bypass: §aON" : "Cobweb Bypass: §cOFF";
                drawContext.drawTextWithShadow(client.textRenderer, text, 5, 5, 0xFFFFFF);
            }
        });
    }
}