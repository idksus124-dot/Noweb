package com.example.nocobwebslowdown;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/**
 * Handles the configuration for the NoCobwebSlowdown mod.
 * Manages the state (enabled/disabled) and persists it to a JSON file.
 */
public class ModConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final File CONFIG_FILE = new File(FabricLoader.getInstance().getConfigDir().toFile(), "nocobwebslowdown.json");

    private static ConfigData data = new ConfigData();

    public static class ConfigData {
        public boolean isEnabled = true; // Default state is enabled
    }

    public static void load() {
        if (CONFIG_FILE.exists()) {
            try (FileReader reader = new FileReader(CONFIG_FILE)) {
                data = GSON.fromJson(reader, ConfigData.class);
                if (data == null) {
                    data = new ConfigData();
                    save(); 
                }
            } catch (IOException e) {
                System.err.println("[NoCobwebSlowdown] Failed to read config file: " + e.getMessage());
                data = new ConfigData();
                save(); 
            }
        } else {
            save();
        }
    }

    public static void save() {
        try (FileWriter writer = new FileWriter(CONFIG_FILE)) {
            GSON.toJson(data, writer);
        } catch (IOException e) {
            System.err.println("[NoCobwebSlowdown] Failed to write config file: " + e.getMessage());
        }
    }

    public static void toggle() {
        data.isEnabled = !data.isEnabled;
        save();
    }

    public static boolean isEnabled() {
        return data.isEnabled;
    }
}